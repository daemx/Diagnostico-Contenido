# 📊 Diagnóstico de Contenido — Deploy en Vercel

Herramienta para diagnosticar empresas, generar estrategia de contenido, descargar PDF y guardar en GitHub. El token de GitHub vive en Vercel (servidor), nunca en el navegador.

---

## Estructura del proyecto

```
diagnostico-app/
├── api/
│   └── save.js          ← API serverless (guarda en GitHub de forma segura)
├── public/
│   └── index.html       ← La app completa
├── vercel.json          ← Configuración de rutas
└── README.md
```

---

## Deploy en 4 pasos

### 1. Sube el proyecto a GitHub

```bash
git init
git add .
git commit -m "primera versión"
git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
git push -u origin main
```

### 2. Importa en Vercel

1. Ve a [vercel.com](https://vercel.com) → **Add New Project**
2. Conecta tu cuenta de GitHub y selecciona este repositorio
3. Framework Preset: **Other** (no es Next.js)
4. Build command: dejar vacío
5. Output directory: `public`
6. Haz clic en **Deploy**

### 3. Configura las variables de entorno en Vercel

En tu proyecto de Vercel → **Settings** → **Environment Variables**, agrega estas 4 variables:

| Variable | Valor | Descripción |
|---|---|---|
| `GITHUB_TOKEN` | `ghp_xxxxxxxxxxxx` | Tu Personal Access Token de GitHub |
| `GITHUB_USER` | `tu-usuario` | Tu usuario de GitHub |
| `GITHUB_REPO` | `nombre-del-repo` | El repo donde se guardarán los diagnósticos |
| `GITHUB_FOLDER` | `diagnosticos` | Carpeta dentro del repo (puedes cambiarla) |

> **Cómo generar el token:**
> GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token
> Permisos necesarios: solo marca **`repo`** (acceso completo a repositorios privados y públicos)

### 4. Redeploy

Después de agregar las variables, ve a **Deployments** → haz clic en los tres puntos del último deploy → **Redeploy**.

Tu app estará en: `https://tu-proyecto.vercel.app`

---

## Cómo funciona el guardado en GitHub

```
Navegador                 Vercel (servidor)              GitHub
   │                           │                            │
   │  POST /api/save           │                            │
   │  { filename, content }    │                            │
   │ ─────────────────────────►│                            │
   │                           │  PUT /repos/.../contents   │
   │                           │  Authorization: token ***  │
   │                           │ ──────────────────────────►│
   │                           │                            │
   │                           │  ← 200 OK + url del archivo│
   │  ← { ok: true, url }      │                            │
```

El token **nunca sale del servidor de Vercel**. El navegador solo ve la respuesta final.

---

## Uso de la app

1. Escribe el nombre de tu agencia en el campo de configuración
2. Llena el formulario de 8 pasos (sector, plataformas, prioridad, etc.)
3. Haz clic en **"Generar diagnóstico y prompts"**
4. El output incluye: diagnóstico, tipos de contenido, hooks, plan mensual y los 5 prompts para Claude
5. **⬇ Descargar PDF** → genera y descarga el diagnóstico completo
6. **🐙 Guardar en GitHub** → hace push al repo configurado en Vercel

---

## Personalización

Para cambiar colores, logo o agregar secciones al PDF, edita `public/index.html`.
Para cambiar la carpeta de destino en GitHub, edita la variable `GITHUB_FOLDER` en Vercel.
